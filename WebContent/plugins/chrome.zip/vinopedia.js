var vptext = chrome.contextMenus.create({"title": "Find on Vinopedia","contexts":["selection"], "onclick": findvp});

function findvp(info, tab) {
  var posturl="http://www.vinopedia.com/add-on/cr/SELTEXT";
  chrome.tabs.create({"url":posturl.replace("SELTEXT", info.selectionText)});

}

